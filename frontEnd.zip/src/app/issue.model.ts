export  interface Issue{
    id:String,
    title:String,
    responsible:String,
    severity:String,
    description:String,
    status:String
    }